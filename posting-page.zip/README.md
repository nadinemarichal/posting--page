# posting--page
Projeto simples de consumo de API usando fetch.