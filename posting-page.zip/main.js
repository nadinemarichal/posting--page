const form = document.querySelector('#post-form');
const titulo = document.querySelector('#titulo');
const conteudo = document.querySelector('#conteudo');

const tituloRenderizar = document.querySelector('#renderizador-titulo');
const conteudoRenderizar = document.querySelector('#renderizador-conteudo');
const idRenderizar = document.querySelector('#renderizador-id');

const url = 'https://jsonplaceholder.typicode.com/posts';

form.addEventListener('submit', async (e) => {
  e.preventDefault();

  const data = { title: titulo.value, body: conteudo.value, userId: 1 };

  try {
    tituloRenderizar.textContent = 'Enviando...';
    conteudoRenderizar.textContent = '';

    const response = await fetch(url, {
      method: 'POST',
      body: JSON.stringify(data),
      headers: { "Content-type": "application/json; charset=UTF-8" }
    });

    const retorno = await response.json();

    tituloRenderizar.textContent = retorno.title;
    conteudoRenderizar.textContent = retorno.body;
    idRenderizar.textContent = "ID criado: " + retorno.id;

    form.reset();
  } catch (error) {
    tituloRenderizar.textContent = 'Erro ao enviar';
    conteudoRenderizar.textContent = error;
  }
});